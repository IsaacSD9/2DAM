from peewee import MySQLDatabase, Model, CharField, FloatField, IntegerField

# Configurar la base de datos
db = MySQLDatabase(
    "2DAM",  # Nombre de la base de datos
    user="usuario",  # Usuario de MySQL
    password="usuario",
    host="localhost",
    port=3306,
)

# Conectar a la base de datos
db.connect()
print("Conexión exitosa a la base de datos.")


# Definir el mapeo de la tabla series_television
class series_television(Model):
    nombre_serie = CharField()
    temporada = IntegerField()
    genero = CharField()
    cadena_television = CharField()
    valoracion = FloatField()

    class Meta:
        database = db
        table_name = "series_television"  # Nombre de la tabla en la base de datos


# TAREA 1: Recuperar y mostrar objetos de un tipo específico (ejemplo: genero 'Comedia')
def tarea1():
    print("Tarea1...")
    series_drama = series_television.select().where(series_television.genero == 'Comedia')
    
    for serie in series_drama:
        print(f"Nombre: {serie.nombre_serie}, Valoración: {serie.valoracion}")



# TAREA 2: Eliminar un solo registro basado en dos atributos y mostrar los registros restantes
def tarea2():
    print("Tarea2...")
    # Ejemplo: eliminar una serie con nombre 'Serie A' y temporada 1
    serie_eliminar = series_television.get((series_television.nombre_serie == 'Aqui No Hay Quien Viva') & 
                                          (series_television.temporada == 5))
    
    serie_eliminar.delete_instance()  # Eliminar el registro

    # Mostrar los registros restantes para verificar la eliminación
    series_restantes = series_television.select()
    for serie in series_restantes:
        print(f"Nombre: {serie.nombre_serie}, Temporada: {serie.temporada}, Género: {serie.genero}, Cadena: {serie.cadena_television}, Valoración: {serie.valoracion}")




# TAREA 3: Eliminar todos los registros que cumplan una condición y mostrar los registros restantes
def tarea3():
    print("Tarea3...")
    # Ejemplo: eliminar todas las series con valoraciones menores a 5
    series_baja_valoracion = series_television.delete().where(series_television.valoracion < 7.2)
    series_baja_valoracion.execute()  # Ejecutar la eliminación

    # Mostrar los registros restantes para confirmar la eliminación
    series_restantes = series_television.select()
    for serie in series_restantes:
        print(f"Nombre: {serie.nombre_serie}, Temporada: {serie.temporada}, Género: {serie.genero}, Cadena: {serie.cadena_television}, Valoración: {serie.valoracion}")


# Ejecutar las tareas
tarea1()
tarea2()
tarea3()

# Cerrar la conexión a la base de datos
db.close()
