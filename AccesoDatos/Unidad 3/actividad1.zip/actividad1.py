from peewee import MySQLDatabase, Model, CharField, FloatField, IntegerField

# Configurar la base de datos
db = MySQLDatabase(
    "2DAM",  # Nombre de la base de datos
    user="usuario",  # Usuario de MySQL
    password="usuario",
    host="localhost",
    port=3306,
)
# Conectar a la base de datos
db.connect()
print("Conexión exitosa a la base de datos.")


# Definir el mapeo de la tabla Herramientas
class series_television(Model):
    nombre_serie = CharField()
    temporada = IntegerField()
    genero = CharField()
    cadena_television = CharField()
    valoracion = FloatField()

    class Meta:
        database = db
        table_name = "series_television"  # Nombre de la tabla en la base de datos


def tabla_existe(nombre_tabla):
    consulta = "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = %s AND table_name = %s"
    cursor = db.execute_sql(consulta, ("2DAM", nombre_tabla))
    resultado = cursor.fetchone()
    return resultado[0] > 0


# Eliminamos la tabla si ya existe para empezar a trabajar desde cero
if tabla_existe(series_television._meta.table_name):
    print(f"La tabla '{series_television._meta.table_name}' existe.")
    db.drop_tables([series_television], cascade=True)
    print(f"Tabla '{series_television._meta.table_name}' eliminada con éxito.")
else:
    print(f"La tabla '{series_television._meta.table_name}' no existe.")


# Crear la tabla si no existe
db.create_tables([series_television])
print("Tabla 'series_television' creada o ya existente.")

series_television.create(nombre_serie="Los Simpsons",temporada="3",genero="Comedia",cadena_television="Antena 3",valoracion="8.3")
series_television.create(nombre_serie="La Que Se Avecina",temporada="1",genero="Comedia",cadena_television="FDF",valoracion="7.4")
series_television.create(nombre_serie="Aqui No Hay Quien Viva",temporada="5",genero="Tragicomedia",cadena_television="FDF",valoracion="8.0")
series_television.create(nombre_serie="Masterchef",temporada="2",genero="Comida",cadena_television="La 1",valoracion="7.0")
series_television.create(nombre_serie="La Voz",temporada="6",genero="Concurso",cadena_television="La 4",valoracion="6.7")

print("Registros de la tabla series_television insertados en la base de datos.")
