from peewee import MySQLDatabase, Model, CharField, FloatField, IntegerField, IntegrityError

# Configurar la base de datos
db = MySQLDatabase(
    "2DAM",  # Nombre de la base de datos
    user="usuario",  # Usuario de MySQL
    password="usuario",
    host="localhost",
    port=3306,
)

# Conectar a la base de datos
db.connect()
print("Conexión exitosa a la base de datos.")


# Definir el mapeo de la tabla series_television
class series_television(Model):
    nombre_serie = CharField()
    temporada = IntegerField()
    genero = CharField()
    cadena_television = CharField()
    valoracion = FloatField()

    class Meta:
        database = db
        table_name = "series_television"  # Nombre de la tabla en la base de datos


# TAREA 1: Recuperar y mostrar objetos de un tipo específico (ejemplo: genero 'Comedia')
def tarea1():
    print("Tarea1...")
    series_comedia = series_television.select().where(series_television.genero == 'Comedia')
    
    for serie in series_comedia:
        print(f"Nombre: {serie.nombre_serie}, Valoración: {serie.valoracion}")


# TAREA 2 con transacción: Eliminar un solo registro basado en dos atributos y mostrar los registros restantes
def tarea2_con_transaccion():
    print("Tarea2 con transacción...")
    try:
        with db.atomic():  # Iniciar transacción
            # Ejemplo: eliminar una serie con nombre 'Stranger Things' y temporada 4
            serie_eliminar = series_television.get(
                (series_television.nombre_serie == 'Stranger Things') & 
                (series_television.temporada == 4)
            )
            serie_eliminar.delete_instance()  # Eliminar el registro

        # Mostrar los registros restantes para verificar la eliminación
        series_restantes = series_television.select()
        for serie in series_restantes:
            print(f"Nombre: {serie.nombre_serie}, Temporada: {serie.temporada}, Género: {serie.genero}, Cadena: {serie.cadena_television}, Valoración: {serie.valoracion}")

    except IntegrityError as e:
        print("Error durante la eliminación:", e)


# TAREA 3 con transacción: Eliminar todos los registros que cumplan una condición y mostrar los registros restantes
def tarea3_con_transaccion():
    print("Tarea3 con transacción...")
    try:
        with db.atomic():  # Iniciar transacción
            # Ejemplo: eliminar todas las series con valoraciones menores a 8.5
            series_baja_valoracion = series_television.delete().where(series_television.valoracion < 8.5)
            series_baja_valoracion.execute()  # Ejecutar la eliminación

        # Mostrar los registros restantes para confirmar la eliminación
        series_restantes = series_television.select()
        for serie in series_restantes:
            print(f"Nombre: {serie.nombre_serie}, Temporada: {serie.temporada}, Género: {serie.genero}, Cadena: {serie.cadena_television}, Valoración: {serie.valoracion}")

    except IntegrityError as e:
        print("Error durante la eliminación:", e)


# Ejecutar las tareas
tarea1()
tarea2_con_transaccion()
tarea3_con_transaccion()

# Cerrar la conexión a la base de datos
db.close()
