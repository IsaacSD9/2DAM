from peewee import MySQLDatabase, Model, CharField, FloatField, IntegerField, IntegrityError

# Configurar la base de datos
db = MySQLDatabase(
    "2DAM",  
    user="usuario",  
    password="usuario",
    host="localhost",
    port=3306,
)

# Definir el mapeo de la tabla series_television
class series_television(Model):
    nombre_serie = CharField()
    temporada = IntegerField()
    genero = CharField()
    cadena_television = CharField()
    valoracion = FloatField()

    class Meta:
        database = db
        table_name = "series_television"  # Nombre de la tabla en la base de datos


# Conectar a la base de datos
db.connect()
print("Conexión exitosa a la base de datos.")


# Función para insertar registros en la tabla series_television
def insertar_series():
    try:
        # Iniciar una transacción utilizando db.atomic()
        with db.atomic():
            # Insertar varias series dentro de la transacción
            series_television.create(
                nombre_serie='Breaking Bad', 
                temporada=5, 
                genero='Drama', 
                cadena_television='AMC', 
                valoracion=9.5
            )
            series_television.create(
                nombre_serie='Friends', 
                temporada=10, 
                genero='Comedia', 
                cadena_television='NBC', 
                valoracion=8.9
            )
            series_television.create(
                nombre_serie='Stranger Things', 
                temporada=4, 
                genero='Ciencia Ficción', 
                cadena_television='Netflix', 
                valoracion=8.7
            )
            series_television.create(
                nombre_serie='La Oficina', 
                temporada=9, 
                genero='Comedia', 
                cadena_television='NBC', 
                valoracion=8.8
            )
            series_television.create(
                nombre_serie='Juego de Tronos', 
                temporada=8, 
                genero='Fantasía', 
                cadena_television='HBO', 
                valoracion=9.3
            )
            print("Series insertadas correctamente.")
    except IntegrityError as e:
        print(f"Error al insertar series: {e}")

# Ejecutar la función para insertar las series
insertar_series()

# Cerrar la conexión a la base de datos
db.close()